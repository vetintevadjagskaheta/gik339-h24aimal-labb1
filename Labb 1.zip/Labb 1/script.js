{
  let name = "Aiman";
  const birthyear = 2005;
  var age = 20;

  console.log(name);
  console.log(birthyear);
  console.log(age);
}

// Uppgift 2
console.log(age);

/* 
1. let och const är block-scopade, vilket betyder att de bara finns inuti blocket {} där de deklareras.
   var är en global variabel och finns även att nå utanför.

2. när console.log() ligger före blocket kraschar koden om jag försöker logga variabler som har deklarerats med let eller const, 
   eftersom de inte finns ännu. Inuti blocket fungerar alla variabler som vanligt. 
   Efter blocket fungerar bara var-variabeln, eftersom let och const är lokala variabler och finns bara inom blocket {}.
   jag tar bort koden som ligger ovanför blocket (även ålder eftersom den fortfarande inte är deklarerad något värde) för att inte få 
   några felmeddelanden, och efter koden låter jag bara var ålder stå kvar eftersom den är global.
*/

// Uppgift 3
console.log('3' == 3);
console.log('3' === 3);

console.log(NaN === NaN);
console.log(null == undefined);
console.log(null === undefined);

// Ternary operator
let resultat = undefined ? "truthy" : "falsy";
console.log(resultat);

/* 
Reflektion Uppgift 3:

1. == jämför värden och kan göra om typer, därför blir '3' == 3 true.
   === jämför både värde och typ, därför blir '3' === 3 false eftersom ena är en sträng och andra ett heltal.
   NaN === NaN är false eftersom NaN aldrig är lika med något.
   null == undefined är true (de räknas som lika), men med === blir de olika.

2. När ett uttryck står för sig själv i en ternary operator eller en if-sats
   kontrolleras den bara om det är truthy eller falsy. Undefined är falsy.

3. NaN används när något inte kan räknas.
   undefined betyder att något inte blvit deklarerat ett värde.
   null används för att visa att något medvetet är tomt.
*/

// Uppgift 4

let name = "Aiman";
console.log(name); // "Aiman"

function greet(name) {
  return "Hej " + name; // "Hej Aiman"
}

// Anropa funktionen och skriv ut resultatet
console.log(greet("Mikaela")); // Hej Mikaela

// Testa att logga name igen
console.log(name); // "Aiman" igen

/* 
1. Funktionsdeklaration: går att anropa innan den står i koden.
   Funktionsuttryck och arrowfunktion: måste skapas först innan man kan anropa dem.
   Jag valde arrowfunktion eftersom jag tycker den är lättast att läsa.

2. Jag måste tänka på var jag anropar funktionen. Eftersom det är en
   arrowfunktion måste jag anropa den efter den är definerad, annars kraschar koden.
   En vanlig funktionsdeklaration hade fungerat innan den stod i koden också.

3. Jag har en variabel i roten som heter name = "Aiman".
   Inne i funktionen har jag också en parameter som heter name.
   Det betyder att parametern "gömmer" den yttre variabeln inne i funktionen.
   Om jag ändrar den globala variabeln name påverkar det utskrifter utanför funktionen. 
   Men om jag skickar in ett argument till funktionen (t.ex. via prompt) är det bara det värdet som används i funktionen.

4. Parameter: namnet i funktionens parentes
   Argument: värdet jag skickar in när jag anropar funktionen
   Variabel: något jag skapar i koden som har ett värde t.ex. name = xx
*/